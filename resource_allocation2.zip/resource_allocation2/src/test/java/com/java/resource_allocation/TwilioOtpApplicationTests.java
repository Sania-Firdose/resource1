package com.java.resource_allocation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwilioOtpApplicationTests {

	@Test
	void contextLoads() {
	}

}
