package com.java.resource_allocation.model;

//import jakarta.persistence.*;

import java.util.List;
//
//@Entity
//@Table(name = "resources")
//public class Resource {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @Column(name = "name", nullable = false)
//    private String name;
//
//    @Column(name = "experience", nullable = false)
//    private int experience;
//
//    @OneToMany(mappedBy = "resource", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
//    private List<ResourceSkill> skills;
//}
//import jakarta.persistence.*;
//import lombok.Data;
//
//@Entity
//@Table(name = "resources")
//@Data
//public class Resource {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @Column(nullable = false, length = 100)
//    private String name;
//
//    @Column(nullable = false)
//    private int experience;
//
//    @OneToMany(mappedBy = "resource", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ResourceSkill> skills;
//}


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "resources")
public class Resource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long resourceId;

    private String resourceName;

    private int experienceYears;

    @ElementCollection
    private List<String> skills; // Comma-separated skills like "Java, Redis, JavaScript"
}
