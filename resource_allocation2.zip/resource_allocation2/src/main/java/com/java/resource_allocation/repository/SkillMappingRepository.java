//package com.java.resource_allocation.repository;
//
//import com.java.resource_allocation.model.ResourceSkill;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface SkillMappingRepository extends JpaRepository<ResourceSkill, Long> {
//
//    /**
//     * Fetch related skills for a given skill.
//     */
//    @Query("SELECT sm.relatedSkill FROM SkillMapping sm WHERE sm.skill = :skill")
//    List<String> findRelatedSkills(@Param("skill") String skill);
//}
