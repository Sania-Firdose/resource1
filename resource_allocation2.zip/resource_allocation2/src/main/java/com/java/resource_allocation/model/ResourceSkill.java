//package com.java.resource_allocation.model;

import jakarta.persistence.*;
import lombok.Data;
//
//@Entity
//@Data
//@Table(name = "resource_skills")
//public class ResourceSkill {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @ManyToOne
//    @JoinColumn(name = "id", nullable = false)
//    private Resource resource;
//
//    @Column(name = "skill", nullable = false)
//    private String skill;
//
//}


import jakarta.persistence.*;
import lombok.Data;

//@Entity
//@Table(name = "resource_skills")
//@Data
//public class ResourceSkill {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @ManyToOne
//    @JoinColumn(name = "id", referencedColumnName = "id", nullable = false)
//    private Resource resource;
//
//    @Column(nullable = false, length = 50)
//    private String skill;
//}
