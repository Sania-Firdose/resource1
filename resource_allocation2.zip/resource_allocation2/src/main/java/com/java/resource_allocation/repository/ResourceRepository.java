package com.java.resource_allocation.repository;
//
//import com.java.resource_allocation.model.Resource;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface ResourceRepository extends JpaRepository<Resource,Long> {
//
//
//    @Query("SELECT r.name FROM Resource r JOIN r.skills s WHERE s.skill IN :skills")
//    List<String> getNamesAccordingToSkills(@Param("skills") List<String> skills);
//}
//package com.example.resourceallocation.repository;


import com.java.resource_allocation.model.Resource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Long> {

//    @Query("SELECT r FROM Resource r WHERE r.experienceYears < :maxExperience " +
//            "AND (:skills IS NULL OR r.skills LIKE %:skills%)")
//@Query("SELECT r FROM Resource r WHERE r.experienceYears < :maxExperience " +
//        "AND (:skills IS NULL OR EXISTS (SELECT s FROM r.skills s WHERE s IN :skills))")
//List<Resource> findBySkillsAndExperience(@Param("skills") String skills,
//                                             @Param("maxExperience") int maxExperience);

//    @Query("SELECT r FROM Resource r WHERE r.experienceYears <:maxExperience " +
//            "AND EXISTS (SELECT s FROM r.skills s WHERE s IN :skills)")
//    List<Resource> findBySkillsAndExperience(@Param("skills") List<String> skills,
//                                             @Param("maxExperience") int maxExperience);

    @Query("SELECT DISTINCT r FROM Resource r " +
            "WHERE r.experienceYears < :maxExperience " +
            "AND EXISTS (SELECT s FROM r.skills s WHERE s IN :skills)")
    List<Resource> findBySkillsAndExperience(@Param("skills") List<String> skills,
                                             @Param("maxExperience") int maxExperience);




}
