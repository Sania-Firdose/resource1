package com.java.resource_allocation.service;
//
//import com.java.resource_allocation.repository.ResourceRepository;
//import com.java.resource_allocation.repository.SkillMappingRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//@Service
//    public class ResourceServiceImpl implements ResourceService
//{
//
//    @Autowired
//    private ResourceRepository resourceRepository;
//
//    @Autowired
//    private SkillMappingRepository skillMappingRepository;
//
//    @Override
//    public List<String> getNamesAccordingToSkills(List<String> skills) {
//        Set<String> matchedResourceNames = new HashSet<>();
//
//        // Fetch resources that match any given skill
//        matchedResourceNames.addAll(resourceRepository.getNamesAccordingToSkills(skills));
//
//        // Fetch related skills from skill_mapping table
//        for (String skill : skills) {
////            List<String> relatedSkills = skillMappingRepository.findRelatedSkills(skill);
////            matchedResourceNames.addAll(resourceRepository.getNamesAccordingToSkills(relatedSkills));
//
//            matchedResourceNames.addAll(skillMappingRepository.findRelatedSkills(skill));
//
//        }
//
//        return new ArrayList<>(matchedResourceNames);
//    }
//}

//package com.example.resourceallocation.service;

//import com.example.resourceallocation.model.Resource;
//import com.example.resourceallocation.repository.ResourceRepository;
import com.java.resource_allocation.model.Resource;
import com.java.resource_allocation.repository.ResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ResourceService {

    @Autowired
    private ResourceRepository repository;

    public List<Resource> getFilteredResources(List<String> skills, int maxExperience) {
        // Join the skills into a comma-separated string
//        String skillsQuery = String.join(",", skills);
//        return repository.findBySkillsAndExperience(skillsQuery, maxExperience);

        return repository.findBySkillsAndExperience(skills, maxExperience);


    }
}

