INSERT INTO resources (resource_name, experience_years, skills) VALUES
('Dennis', 4, 'Java, Spring, JMS, MySQL, Angular, React, Web Services, NodeJS'),
('Thompson', 7, 'Java, Oracle, React, Angular, JavaScript, REST API'),
('Kim', 12, 'Java, JSP, Spring, Oracle, MySQL, PostgreSQL, MongoDB, REST API, Docker, Redis'),
('Aisha', 9, 'Angular, JavaScript, NodeJS, REST API, Web Services, Docker, SQL Server, PostgreSQL'),
('Maya', 5, 'Spring, Spring Boot, Hibernate, MySQL, PostgreSQL, NodeJS, Python'),
('Kumar', 3, 'Java, Redis, MySQL, JavaScript');
